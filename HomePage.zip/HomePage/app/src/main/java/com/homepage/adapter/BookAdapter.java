package com.homepage.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.homepage.MainActivity;
import com.homepage.R;
import com.homepage.model.Book;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.bookViewHolder> {
    Context context;
    List<Book> bookList;

    public BookAdapter(Context context, List<Book> bookList) {
        this.context = context;
        this.bookList = bookList;
    }

    @NonNull
    @Override
    public bookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.product_row_item, parent, false);
        return new bookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull bookViewHolder holder, int position) {
        holder.bookImage.setImageResource(bookList.get(position).getImageurl());
        holder.name.setText(bookList.get(position).getName());
        holder.price.setText(bookList.get(position).getPrice());
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public static final class bookViewHolder extends RecyclerView.ViewHolder{
        ImageView bookImage;
        TextView price, name;
        public bookViewHolder(@NonNull View itemView)
        {
            super(itemView);
            bookImage = itemView.findViewById(R.id.img_book);
            price = itemView.findViewById(R.id.price);
            name = itemView.findViewById(R.id.name);
        }
    }

}
