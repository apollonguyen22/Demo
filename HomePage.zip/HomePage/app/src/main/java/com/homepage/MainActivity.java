package com.homepage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;

import com.homepage.adapter.BookAdapter;
import com.homepage.model.Book;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView bookRecycler;
    BookAdapter bookAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<Book> booksList = new ArrayList<>();
        booksList.add(new Book("Mắt Biếc", "58.000đ", R.drawable.matbiec));
        booksList.add(new Book("Nhà Giả Kim", "38.000đ", R.drawable.nhagiakim));
        booksList.add(new Book("21 Bài Học Cho Thế Kỉ 21", "158.000đ", R.drawable.baihoc));
        setBookRecycler(booksList);
    }
    private void setBookRecycler(List<Book> booksList){
        bookRecycler = findViewById(R.id.book_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        bookRecycler.setLayoutManager(layoutManager);
        bookAdapter = new BookAdapter(this, booksList);


    }
}